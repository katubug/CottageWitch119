by Wooferscoots
https://www.planetminecraft.com/member/wooferscoots/

Permissions:
You're welcome to modify the packs to fit your own needs or include it in a pack of your own. However do not make profit
off of the textures, repost the pack, or claim the textures as your own. Thank you!

Please do not re-upload my pack anywhere.
Do not take and use the assets within the pack without permission.

- L-White
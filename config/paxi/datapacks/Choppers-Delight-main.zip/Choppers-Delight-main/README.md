# Choppers-Delight
Datapack for modded woods for chopping purposes in Farmer's Delight.

If you have recipes to add to this, use the format within the current files to prevent cross-mod log spam!

Current listing:
* BYG
* DruidCraft
* Twist (no stripped log/wood, so it goes directly to planks)
* Blue Skies
